import google.generativeai as genai
import json
import jwt
import datetime
import gspread
from google.oauth2.service_account import Credentials

def handler(request):
    # Set CORS headers for preflight requests
    if request.method == 'OPTIONS':
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)

    # Set CORS headers for main requests
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
    }

    # --- Security Zone: Your core IP is stored here ---
    # 1. Paste your secret API key here
    API_KEY = 'PASTE_YOUR_SECRET_GEMINI_API_KEY_HERE'

    # 2. Paste your complete V12.4 Master Prompt here
    MASTER_PROMPT_V12_4 = """
    ### THE PF CREATIVE STUDIO SYSTEM (MASTER FILE V12.4 - BLUEPRINT EDITION)
    ... (Paste your complete V12.4 Master Prompt text here) ...
    """

    # 3. Authentication settings
    JWT_SECRET = 'your-secret-jwt-key-change-this-in-production'
    
    # 4. Google Sheets Configuration (Optional - for live customer management)
    USE_GOOGLE_SHEETS = False  # Set to True to enable Google Sheets integration
    GOOGLE_SHEETS_ID = 'your-google-sheets-id-here'  # Replace with your sheet ID
    
    # Fallback user accounts (used when Google Sheets is disabled)
    FALLBACK_USERS = {
        'admin': 'password123',
        'user1': 'mypassword',
        'demo': 'demo123'
    }
    # --- End Security Zone ---

    def get_user_credentials():
        """Get user credentials from Google Sheets or fallback to hardcoded users"""
        if USE_GOOGLE_SHEETS:
            try:
                # Google Sheets integration
                scope = ['https://spreadsheets.google.com/feeds',
                        'https://www.googleapis.com/auth/drive']
                
                # You need to upload service-account.json to your Cloud Function
                creds = Credentials.from_service_account_file('service-account.json', scopes=scope)
                client = gspread.authorize(creds)
                
                # Open the customer database sheet
                sheet = client.open_by_key(GOOGLE_SHEETS_ID).sheet1
                
                # Get all records
                records = sheet.get_all_records()
                
                # Convert to username:password dictionary
                user_dict = {}
                for record in records:
                    if record.get('Status', '').lower() == 'active':
                        user_dict[record['Username']] = record['Password']
                
                return user_dict
            except Exception as e:
                # If Google Sheets fails, fall back to hardcoded users
                print(f"Google Sheets error: {e}")
                return FALLBACK_USERS
        else:
            return FALLBACK_USERS

    # Handle login requests
    if request.path == '/login':
        try:
            request_json = request.get_json(silent=True)
            if not request_json or 'username' not in request_json or 'password' not in request_json:
                return (json.dumps({'success': False, 'message': 'Username and password required'}), 400, headers)

            username = request_json['username']
            password = request_json['password']

            # Get current user credentials
            valid_users = get_user_credentials()

            # Check credentials
            if username in valid_users and valid_users[username] == password:
                # Generate JWT token
                token = jwt.encode({
                    'username': username,
                    'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
                }, JWT_SECRET, algorithm='HS256')

                return (json.dumps({
                    'success': True,
                    'token': token,
                    'message': 'Login successful'
                }), 200, headers)
            else:
                return (json.dumps({
                    'success': False,
                    'message': 'Invalid username or password'
                }), 401, headers)

        except Exception as e:
            return (json.dumps({'success': False, 'message': str(e)}), 500, headers)

    # Handle customer creation requests (for payment webhooks)
    if request.path == '/create-customer':
        try:
            request_json = request.get_json(silent=True)
            if not request_json or 'email' not in request_json:
                return (json.dumps({'error': 'Email required'}), 400, headers)

            email = request_json['email']
            username = request_json.get('username', email.split('@')[0])
            password = request_json.get('password', generate_secure_password())

            if USE_GOOGLE_SHEETS:
                # Add customer to Google Sheets
                scope = ['https://spreadsheets.google.com/feeds',
                        'https://www.googleapis.com/auth/drive']
                
                creds = Credentials.from_service_account_file('service-account.json', scopes=scope)
                client = gspread.authorize(creds)
                sheet = client.open_by_key(GOOGLE_SHEETS_ID).sheet1
                
                # Add new row
                sheet.append_row([
                    username,
                    password,
                    email,
                    datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'Active'
                ])

                return (json.dumps({
                    'success': True,
                    'username': username,
                    'password': password,
                    'message': 'Customer account created'
                }), 200, headers)
            else:
                return (json.dumps({
                    'error': 'Customer creation not enabled. Enable Google Sheets integration.'
                }), 400, headers)

        except Exception as e:
            return (json.dumps({'error': str(e)}), 500, headers)

    # Handle script generation requests (requires authentication)
    try:
        # Check for authentication token
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return (json.dumps({'error': 'Authentication required'}), 401, headers)

        token = auth_header.split(' ')[1]
        try:
            decoded_token = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            username = decoded_token['username']
        except jwt.ExpiredSignatureError:
            return (json.dumps({'error': 'Token expired'}), 401, headers)
        except jwt.InvalidTokenError:
            return (json.dumps({'error': 'Invalid token'}), 401, headers)

        # Parse request JSON
        request_json = request.get_json(silent=True)
        if not request_json or 'project_info' not in request_json:
            return (json.dumps({'error': 'Invalid request: missing project_info'}), 400, headers)

        user_project_info = request_json['project_info']
        full_prompt_for_gemini = MASTER_PROMPT_V12_4 + "\n\n" + user_project_info

        # Configure and call Gemini API
        genai.configure(api_key=API_KEY)
        model = genai.GenerativeModel('gemini-1.5-flash')
        response = model.generate_content(full_prompt_for_gemini)

        # Check if there's returned content
        if response.parts:
            result_text = response.text
        else:
            # If no content, it might be blocked by safety settings
            result_text = "AI was unable to generate a response. This might be due to content safety policies or prompt issues. Please try adjusting your input."

        return (json.dumps({'result': result_text}), 200, headers)

    except Exception as e:
        return (json.dumps({'error': str(e)}), 500, headers)

def generate_secure_password():
    """Generate a secure random password"""
    import random
    import string
    
    length = 12
    characters = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(random.choice(characters) for _ in range(length))
    return password

