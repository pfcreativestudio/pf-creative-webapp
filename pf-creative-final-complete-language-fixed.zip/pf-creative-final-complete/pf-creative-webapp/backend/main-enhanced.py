import json
import jwt
import datetime
from google.cloud import firestore
import google.generativeai as genai
import os

# Initialize Firestore client
db = firestore.Client()

def handler(request):
    # Set CORS headers for preflight requests
    if request.method == 'OPTIONS':
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)

    # Set CORS headers for main requests
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
    }

    # --- Security Zone: Your core IP is stored here ---
    # 1. Paste your secret API key here
    API_KEY = 'PASTE_YOUR_SECRET_GEMINI_API_KEY_HERE'

    # 2. Paste your complete V12.4 Master Prompt here
    MASTER_PROMPT_V12_4 = """
    ### THE PF CREATIVE STUDIO SYSTEM (MASTER FILE V12.4 - BLUEPRINT EDITION)
    ... (Paste your complete V12.4 Master Prompt text here) ...
    """

    # 3. Authentication settings
    JWT_SECRET = 'your-secret-jwt-key-change-this-in-production'
    # --- End Security Zone ---

    def get_users_collection():
        """Get or create users collection in Firestore"""
        return db.collection('pf_creative_users')

    def verify_token(token):
        """Verify JWT token"""
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None

    # Route handling based on path
    path = request.path
    method = request.method

    # Handle login requests
    if path == '/login' and method == 'POST':
        try:
            request_json = request.get_json(silent=True)
            if not request_json or 'username' not in request_json or 'password' not in request_json:
                return (json.dumps({'success': False, 'message': 'Username and password required'}), 400, headers)

            username = request_json['username']
            password = request_json['password']

            # Check user in Firestore
            users_ref = get_users_collection()
            user_doc = users_ref.document(username).get()
            
            if not user_doc.exists:
                return (json.dumps({'success': False, 'message': 'Invalid username or password'}), 401, headers)
            
            user_data = user_doc.to_dict()
            if user_data.get('password') != password:
                return (json.dumps({'success': False, 'message': 'Invalid username or password'}), 401, headers)

            # Generate JWT token
            token = jwt.encode({
                'username': username,
                'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
            }, JWT_SECRET, algorithm='HS256')

            return (json.dumps({
                'success': True,
                'token': token,
                'message': 'Login successful'
            }), 200, headers)

        except Exception as e:
            return (json.dumps({'success': False, 'message': str(e)}), 500, headers)

    # Admin endpoints for user management
    elif path == '/admin/users' and method == 'GET':
        try:
            users_ref = get_users_collection()
            users = []
            
            for doc in users_ref.stream():
                user_data = doc.to_dict()
                users.append({
                    'username': doc.id,
                    'password': user_data.get('password', ''),
                    'created_at': user_data.get('created_at', '')
                })
            
            return (json.dumps({'users': users}), 200, headers)
        
        except Exception as e:
            return (json.dumps({'error': f'Failed to get users: {str(e)}'}), 500, headers)

    elif path == '/admin/add-user' and method == 'POST':
        try:
            request_json = request.get_json(silent=True)
            if not request_json or 'username' not in request_json or 'password' not in request_json:
                return (json.dumps({'error': 'Username and password required'}), 400, headers)

            username = request_json['username']
            password = request_json['password']

            users_ref = get_users_collection()
            user_doc = users_ref.document(username)
            
            # Check if user already exists
            if user_doc.get().exists:
                return (json.dumps({'error': 'Username already exists'}), 400, headers)
            
            # Add new user
            user_doc.set({
                'password': password,
                'created_at': datetime.datetime.utcnow().isoformat()
            })
            
            return (json.dumps({'success': True, 'message': 'User added successfully'}), 200, headers)
        
        except Exception as e:
            return (json.dumps({'error': f'Failed to add user: {str(e)}'}), 500, headers)

    elif path == '/admin/update-user' and method == 'PUT':
        try:
            request_json = request.get_json(silent=True)
            if not request_json or 'username' not in request_json or 'password' not in request_json:
                return (json.dumps({'error': 'Username and password required'}), 400, headers)

            username = request_json['username']
            password = request_json['password']

            users_ref = get_users_collection()
            user_doc = users_ref.document(username)
            
            if not user_doc.get().exists:
                return (json.dumps({'error': 'User not found'}), 404, headers)
            
            # Update user password
            user_doc.update({'password': password})
            
            return (json.dumps({'success': True, 'message': 'User updated successfully'}), 200, headers)
        
        except Exception as e:
            return (json.dumps({'error': f'Failed to update user: {str(e)}'}), 500, headers)

    elif path == '/admin/delete-user' and method == 'DELETE':
        try:
            request_json = request.get_json(silent=True)
            if not request_json or 'username' not in request_json:
                return (json.dumps({'error': 'Username required'}), 400, headers)

            username = request_json['username']

            users_ref = get_users_collection()
            user_doc = users_ref.document(username)
            
            if not user_doc.get().exists:
                return (json.dumps({'error': 'User not found'}), 404, headers)
            
            # Delete user
            user_doc.delete()
            
            return (json.dumps({'success': True, 'message': 'User deleted successfully'}), 200, headers)
        
        except Exception as e:
            return (json.dumps({'error': f'Failed to delete user: {str(e)}'}), 500, headers)

    # Chat endpoint for luxury chatroom
    elif path == '/chat' and method == 'POST':
        try:
            # Check for authentication token
            auth_header = request.headers.get('Authorization')
            if not auth_header or not auth_header.startswith('Bearer '):
                return (json.dumps({'error': 'Authentication required'}), 401, headers)

            token = auth_header.split(' ')[1]
            user_data = verify_token(token)
            
            if not user_data:
                return (json.dumps({'error': 'Invalid or expired token'}), 401, headers)

            request_json = request.get_json(silent=True)
            if not request_json or 'message' not in request_json:
                return (json.dumps({'error': 'Message required'}), 400, headers)

            user_message = request_json['message']
            
            # Generate response using Gemini with master prompt
            genai.configure(api_key=API_KEY)
            model = genai.GenerativeModel('gemini-1.5-flash')
            
            # Combine master prompt with user message
            full_prompt = f"{MASTER_PROMPT_V12_4}\n\nUser Message: {user_message}\n\nPlease respond as the Director-Grade AI assistant, maintaining the professional and expert tone while helping with video script creation."
            
            response = model.generate_content(full_prompt)
            
            if response.parts:
                ai_response = response.text
            else:
                ai_response = "I apologize, but I'm unable to generate a response at the moment. Please try rephrasing your request."

            return (json.dumps({
                'success': True,
                'response': ai_response,
                'user': user_data['username'],
                'timestamp': datetime.datetime.utcnow().isoformat()
            }), 200, headers)

        except Exception as e:
            return (json.dumps({'error': f'Chat response failed: {str(e)}'}), 500, headers)

    # Handle script generation requests (legacy endpoint)
    elif method == 'POST':
        try:
            # Check for authentication token
            auth_header = request.headers.get('Authorization')
            if not auth_header or not auth_header.startswith('Bearer '):
                return (json.dumps({'error': 'Authentication required'}), 401, headers)

            token = auth_header.split(' ')[1]
            user_data = verify_token(token)
            
            if not user_data:
                return (json.dumps({'error': 'Invalid or expired token'}), 401, headers)

            # Parse request JSON
            request_json = request.get_json(silent=True)
            if not request_json or 'project_info' not in request_json:
                return (json.dumps({'error': 'Invalid request: missing project_info'}), 400, headers)

            user_project_info = request_json['project_info']
            full_prompt_for_gemini = MASTER_PROMPT_V12_4 + "\n\n" + user_project_info

            # Configure and call Gemini API
            genai.configure(api_key=API_KEY)
            model = genai.GenerativeModel('gemini-1.5-flash')
            response = model.generate_content(full_prompt_for_gemini)

            # Check if there's returned content
            if response.parts:
                result_text = response.text
            else:
                result_text = "AI was unable to generate a response. This might be due to content safety policies or prompt issues. Please try adjusting your input."

            return (json.dumps({'result': result_text}), 200, headers)

        except Exception as e:
            return (json.dumps({'error': str(e)}), 500, headers)

    else:
        return (json.dumps({'error': 'Endpoint not found'}), 404, headers)

